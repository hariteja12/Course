package com.cg.course.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.course.beans.Course;
import com.cg.course.dao.CourseRepository;
import com.cg.course.exception.CourseException;
@Service
public class CourseServiceImpl implements CourseService {
	@Autowired
	private CourseRepository courseRepository;

	@Override
	public List<Course> getAllCourses() throws CourseException {
		try {
			return courseRepository.findAll();
		} catch (Exception e) {
			throw new CourseException(e.getMessage());
		}
	}

	@Override
	public List<Course> addCourse(Course cour) throws CourseException {

		if (courseRepository.existsById(cour.getCourseId())) {
			throw new CourseException("Already Exists");
		}
		courseRepository.save(cour);
		return getAllCourses();
	}

	@Override
	public List<Course> deleteCourse(int courseId) throws CourseException {

		if (!courseRepository.existsById(courseId) ){
			throw new CourseException("Not Exists");
		}
		courseRepository.deleteById(courseId);
		return getAllCourses();
	}

	@Override
	public List<Course> updateCourse(Course cour) throws CourseException {
		if (courseRepository.existsById(cour.getCourseId())) {
			courseRepository.save(cour);
			return getAllCourses();
		} else {
			throw new CourseException("Not exists");
		}
	}

	@Override
	public List<Course> getCourseByMode(String mode) throws CourseException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Course getCourseById(int courseId) throws CourseException {

		if (!courseRepository.existsById(courseId)) {
			throw new CourseException("Employee with id " + courseId + "does not exist");
		}
		return courseRepository.findById(courseId).get();
	}
}
