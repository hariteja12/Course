package com.cg.course.service;

import java.util.List;

import com.cg.course.beans.Course;
import com.cg.course.exception.CourseException;


public interface CourseService {
	 List<Course> getAllCourses() throws CourseException;
	    List<Course> addCourse(Course pro) throws CourseException;
	    List<Course> deleteCourse(int courseId) throws CourseException;
	    List<Course> updateCourse(Course pro) throws CourseException;
	    List<Course> getCourseByMode(String mode) throws CourseException;
	    Course getCourseById(int courseId) throws CourseException;
}
