package com.cg.course.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.course.beans.Course;

public interface CourseRepository extends JpaRepository<Course, Integer> {
	@Query("from Course where mode=:mode")
	List<Course> findCourseByMode(@Param("mode") String mode);

}
