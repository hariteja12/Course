package com.cg.course.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.course.beans.Course;
import com.cg.course.exception.CourseException;
import com.cg.course.service.CourseService;


@RestController
public class CourseController {

	@Autowired
	private CourseService courseService;

	@RequestMapping("/Courses")
	public List<Course> getCourses() throws CourseException {
		return courseService.getAllCourses();
	}

	@PostMapping("/Courses/add")
	public List<Course> addCourse(@RequestBody Course cour) throws CourseException {
		return courseService.addCourse(cour);
	}

	@DeleteMapping("/Courses/{courseId}")
	public List<Course> deleteCourses(@PathVariable int courseId) throws CourseException {
		courseService.deleteCourse(courseId);
		return courseService.getAllCourses();
	}

	@PutMapping("/Courses/update")
	public List<Course> updateCourses(@RequestBody Course cour) throws CourseException {

		return courseService.updateCourse(cour);
	}

	@GetMapping("/Courses/mode")
	public List<Course> getCourseByMode(@RequestParam("mode") String mode) throws CourseException {
		return courseService.getCourseByMode(mode);
	}

	@GetMapping("/Courses/{courseId}")
	public Course getCourseById(@PathVariable int courseId) throws CourseException {
		return courseService.getCourseById(courseId);

	}
}